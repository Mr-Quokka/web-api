<?php
use GuzzleHttp\Client;

require __DIR__ . '/../vendor/autoload.php';
try{
$client = new GuzzleHttp\Client(['base_uri' => 'http://localhost:8888']);
$response = $client->request('GET', '');
$code = $response->getStatusCode();
$body = $response->getBody();
echo $code;
echo "\n";
echo (string) $body;
}
catch (ConnectException $ee){ echo "error in URL";}
catch (ClientException $e) {
    echo Psr7\Message::toString($e->getRequest());
    echo Psr7\Message::toString($e->getResponse());
}



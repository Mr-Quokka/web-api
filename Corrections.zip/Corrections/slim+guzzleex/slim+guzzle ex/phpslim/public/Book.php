<?php
namespace BL;
Class Book{
    public int $isbn;
    public string $title;

public function __construct(int $isbn,string $title){
    $this->isbn=$isbn;
    $this->title=$title;

}

}
<?php
namespace BL;
Class Book2 implements \JsonSerializable{
    private int $isbn;
    private string $title;

public function __construct(int $isbn,string $title){
    $this->isbn=$isbn;
    $this->title=$title;

}
    public function jsonSerialize()
    {
        $vars = get_object_vars($this);

        return $vars;
    }

}
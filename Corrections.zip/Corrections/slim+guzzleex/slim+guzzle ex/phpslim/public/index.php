<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;
use Slim\Factory\AppFactory;

$loader = require __DIR__ . '/../vendor/autoload.php';
//for namespace BL PSR4 here namespace ; dir
$loader->addPsr4('BL\\', __DIR__);
$app = AppFactory::create();

$app->get('/', function (Request $request, Response $response, $args) {
    $response->getBody()->write("Hello world!");
    return $response;
});

$app->get('/books/[{id}]', function ($request, $response, array $args) {
// Apply changes to books or book identified by $args['id'] if specified.
// /[{id}] optional -> all books or book id
    try{
        //var_dump($request->getMethod());
        // print the verb
        $id = $args['id'] ?? 0;
        $book = array('isbn' => $id, 'title' => 'mybook');
        $payload = json_encode($book);
        $response->getBody()->write($payload);
        return $response->withHeader('Content-type', 'application/json')->withStatus(200);}
    catch (Exception $e) {
        throw new HttpInternalServerErrorException();
    }
});

$app->any('/books2/[{id}]', function ($request, $response, array $args) {
// Apply changes to books or book identified by $args['id'] if specified.
// /[{id}] optional -> all books or book id
    $book = new BL\Book(1, 'title');
    var_dump($book);
    $payload = json_encode($book);
    var_dump($payload); // ok if public
    $obj = new stdClass();
    $obj->isbn =1 ;
    $obj->title='title';
    $payload = json_encode($obj);
    var_dump($payload); // ok
    $book = new BL\Book2(1, 'title');
    $payload = json_encode($book);
    var_dump($payload); // ok if private
    $response->getBody()->write($payload);
    return $response->withHeader('Content-type', 'application/json')->withStatus(200);
});
$app->run();


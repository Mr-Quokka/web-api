package com.example.serv;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

interface BookRepository extends CrudRepository<Book, Long> {

	List<Book> findByname(String name);

	Book findById(long id);
}
package com.example.serv;


public class BookException extends RuntimeException {

  public BookException(String exception) {
    super(exception);
  }

}

package com.example.serv;

import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Column;
import lombok.Data;

@Entity
@Data
public class Book {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private  Long isbn;
@Column(name = "name")
	private String name;
@Column(name = "author")
	private String author;

Book() {
	this.name="";
	this.author="";

}

	public Book( String name, String author) {
		this.name = name;
		this.author = author;
	}

	public Long getIsbn() {
		return isbn;
	}

	public String getName() {
		return name;
	}

	@Override
  public int hashCode() {
    return Objects.hash(this.isbn, this.name, this.author);
  }
	@Override
  public String toString() {
    return "Book{" + "isbn=" + this.isbn + '\'' + '}' ;
  }

	@Override
	  public boolean equals(Object o) {

	    if (this == o)
	      return true;
	    if (!(o instanceof Book))
	      return false;
	    Book b = (Book) o;
	    return Objects.equals(this.isbn, b.isbn) ;
	  }


}

 package com.example.serv;

import java.io.*;
import java.util.*;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.*;
import org.springframework.hateoas.CollectionModel;
import org.springframework.hateoas.EntityModel;
import org.springframework.hateoas.IanaLinkRelations;
import org.springframework.hateoas.Link;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.springframework.http.ResponseEntity;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
public class BookController {

Logger logger = LoggerFactory.getLogger(BookController.class);
private final BookRepository repository;

BookController(BookRepository repository) {
    this.repository = repository;
	repository.save(new Book("book", "Bauer"));
     }

@RequestMapping("/")
    public String index() {
        logger.trace("A TRACE Message");
        logger.debug("A DEBUG Message");
        logger.info("An INFO Message");
        logger.warn("A WARN Message");
        logger.error("An ERROR Message");
	
        return "Trace working";
    }


@GetMapping("/books2/{isbn}")
  EntityModel<Book> one(@PathVariable Long isbn) {

    Book b = repository.findById(isbn) //
        .orElseThrow(() -> new BookException("not found"));

    return EntityModel.of(b, //
        linkTo(methodOn(BookController.class).one(isbn)).withSelfRel(),
        linkTo(methodOn(BookController.class).getallbooks()).withRel("books"));
  }


@RequestMapping(value = "/books", method = RequestMethod.GET, produces = "application/json")
public @ResponseBody List<Book> getallbooks() {

List<Book> books = new ArrayList<>();
for(Book b: repository.findAll()) {
    books.add(b);
    }
return books;
}

@GetMapping("/books/{isbn}")
  Book fone(@PathVariable Long isbn) {

    return repository.findById(isbn)
      .orElseThrow(() -> new BookException("error get isbn "+isbn));
  }


@PostMapping(value= "/postbook", consumes = "application/json")
    public void addbook(@RequestBody Book b)
	{
try{
repository.save(b);
}
catch (Exception e)
{throw new BookException("error in list creation");}
}

}
